This package contains problems:
- 1.7 [diagram](anotheranimal.uml)