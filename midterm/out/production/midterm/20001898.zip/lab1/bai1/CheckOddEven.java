package lab1.bai1;

// 1.2
public class CheckOddEven {
    public static void main(String[] args) {
        int number = 49;
        if (number % 2 == 0) {
            System.out.println("Even Number");
        } else {
            System.out.println("Odd Number");
        }
        System.out.println("Bye!");
    }
}
