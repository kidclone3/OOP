package hw6.anotheranimal;

public class Cat extends Animal {
    @Override
    public void greeting() {
        System.out.println("Meow!");
    }
}
