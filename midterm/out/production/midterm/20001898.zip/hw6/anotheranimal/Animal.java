package hw6.anotheranimal;

abstract public class Animal {
    abstract public void greeting();
}
