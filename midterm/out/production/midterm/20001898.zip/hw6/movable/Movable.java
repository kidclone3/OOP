package hw6.movable;

public interface Movable {
  void moveUp();

  void moveDown();

  void moveLeft();

  void moveRight();
}
