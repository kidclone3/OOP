package hw6.geometricobject;

public interface GeometricObject {
  double getArea();

  double getPerimeter();
}
