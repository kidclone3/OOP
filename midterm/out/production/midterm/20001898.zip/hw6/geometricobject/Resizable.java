package hw6.geometricobject;

public interface Resizable {
    void resize(int percent);
}
