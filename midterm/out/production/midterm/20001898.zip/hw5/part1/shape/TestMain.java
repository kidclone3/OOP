package hw5.part1.shape;

public class TestMain {
  public static void main(String[] args) {
    ShapeTest.main(null);
    SquareTest.main(null);
    RectangleTest.main(null);
  }
}
